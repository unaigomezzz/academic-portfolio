---
output: pdf_document
---

# Introducción {.unlisted .unnumbered}

<!-- \section*{Las opciones financieras} -->

Las opciones financieras son un tipo de contrato que da el derecho pero no la obligación de comprar un activo a un precio previamente acordado en un periodo de tiempo determinado. Esto nos permite comprar activos antes de que tengan valor en el mercado. Por ejemplo, si nos interesa una acción pero no estamos seguros de que su valor aumente en el futuro podemos comprarlo mediante una opción: pagaremos una pequeña cantidad llamada prima, y luego si el valor de mercado de la acción aumenta compraremos las acciones en el precio acordado previamente.

<!-- \section*{Breve historia de las opciones}-->

Los modelos matemáticos de las opciones financieras, aunque aún no definidos de esa forma, empezaron mucho antes que la publicación del modelo de Black-Scholes en 1973. Hace más de dos mil años un matemático griego, Tales de Mileto, compró los derechos de uso de unas almazaras[^almazaras], especulando que este año la cosecha de olivas sería mayor a la que se esperaba. En el momento de la cosecha, dado que la cosecha  fue más abundante de lo esperado, tal y como había sospechado Tales, este matemático ejerció su derecho de uso de las almazaras generando más beneficio que otros. Esto es un ejemplo de un contrato de opciones: alguien compra derechos de uso para ejercerlos después si resulta beneficioso.

Como hemos dicho, las opciones permiten comprar un bien tiempo antes de que este tenga un valor significativo en el mercado. Otro caso histórico fue la tulipomanía [@bbcmundoComoFueCrisis2018] en Holanda, que gracias a las opciones se podían comprar antes de que floreciesen. Siendo esto así, alrededor del año 1600, se especulo tanto con los tulipanes que llegaron a tener el valor de una casa en el canal de Amsterdam. En 1637 un solo bulbo de tulipán era suficiente para mantener a una familia holandesa durante media vida. A esta fiebre de los tulipanes se le llamo *tulipomanía*. De todas formas, esto duro poco ya que el precio cayó en picado a mediados de 1937. En ese año se compró gran cantidad de opciones sobre tulipanes meses antes de la temporada de plantación. Cuando llegó la temporada de los tulipanes, a pesar de las expectativas generadas, no había suficientes compradores para todos los tulipanes con opción de compra, por lo que el precio del tulipán cayó en picado, provocando una crisis que se conoce como la primera gran burbuja especulativa de la historia.

[^almazaras]: Una almazara es un molino diseñado para triturar semillas ricas en oleo, como las olivas.

El primer mercado de opciones organizado se estableció en Londres en el siglo XVII, comerciando tanto con opciones *put*, que daban el derecho a vender los activos mediante opciones, y *call*, que daban el derecho a comprar los activos mediante opciones. En Estados Unidos los comienzos del comercio de opciones empezaron en el siglo XIX.

La primera aplicación matemática conocida fue hecha por el matemático francés Louis Bachelier. Su tesis uso un concepto conocido como **movimiento Browniano** o **proceso Wiener** para modelar los precios de las opciones. Estas ideas fueron decisivas en los modelos posteriores.

<!-- \section*{El modelo de Black-Scholes} -->

El modelo de Black-Scholes empezó con las investigaciones iniciales de Fisher Black y Robert Merton[@blackPricingOptionsCorporate]. Más tarde, en el Instituto Tecnológico de Massachusetts empezaron a trabajar en el modelo original que conocemos como Black-Scholes.

En 1973 se publicó por primera vez el modelo en el articulo *The Pricing of Options and Corporate Liabilities* [@blackPricingOptionsCorporate] de Black y Scholes, pero aun le quedaba mucho para ser un proceso realmente fluido.

Tras la publicación del modelo, Robert Merton, que también trabajaba en el M.I.T., hizo sus propias contribuciones en el articulo *Theory of Rational Option Pricing*[@mertonTheoryRationalOption]. Merton sugirió varias ampliaciones del modelo, incluyendo una versión de la formula de Black-Scholes que aceptaba supuestos mas débiles y por lo tanto era mas ampliamente utilizable.


